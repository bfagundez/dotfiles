return {
	{ "honza/vim-snippets" },
	{ "dcampos/nvim-snippy" },
	{ "dcampos/cmp-snippy" },
}
